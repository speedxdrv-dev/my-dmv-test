### 1.1.0 [02.05.2024] - View other user's profile

- View other user's profile -> Click on any user in the leaderboard
    - See when they're joined
    - See how many points they have
    - What quizzes they've played
        - You can do the same quiz -> Click on the quiz
        - Analyse their performance
- Release page

### 1.0.0 [27.04.2024] - Initial release

- Multiple-choice questions
- Score tracking
- Timer tracking
- Leaderboard
- Randomized questions (over 4,146 questions)
- A lot of categories
- Choose between multiple difficulty levels
- User-friendly interface
