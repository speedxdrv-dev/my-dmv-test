package com.tom.supaquiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
