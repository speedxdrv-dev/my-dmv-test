import 'package:flutter/material.dart';

abstract class AppColors {
  static const primary = Color(0xFFFFBA27);
  static const blue = Color(0xFF00b4d8);
  static const green = Color(0xFFa7c957);
  static const red = Color(0xFFe5383b);
}
