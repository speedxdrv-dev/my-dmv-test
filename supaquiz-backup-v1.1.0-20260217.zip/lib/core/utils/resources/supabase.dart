import 'package:supabase_flutter/supabase_flutter.dart';

// Get a reference your Supabase client
final supabase = Supabase.instance.client;