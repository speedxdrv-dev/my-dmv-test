/// Supabase 连接状态
class SupabaseConfig {
  SupabaseConfig._();

  static bool isReachable = true;
}
